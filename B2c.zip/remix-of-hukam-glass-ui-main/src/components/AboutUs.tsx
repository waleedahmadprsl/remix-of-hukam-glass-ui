import { motion } from "framer-motion";

const AboutUs = () => (
  <section id="about-us" className="py-20">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-12 items-center">
        {/* Text */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
            Built in Mirpur,{" "}
            <span className="text-brand-blue">for Mirpur.</span>
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-4">
            We are a team of three brothers on a mission to bring hyper-local, high-speed commerce to our city. No more waiting days for deliveries.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            HUK<span className="text-brand-blue font-semibold">A</span>M was born from a simple frustration — why should Mirpur wait 3-5 days for a phone charger? We deliver premium tech accessories to your doorstep in under 60 minutes, because your time matters.
          </p>
        </motion.div>

        {/* Team photo placeholder */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="glass-card p-3 aspect-[4/3] flex items-center justify-center"
        >
          <div className="w-full h-full rounded-xl bg-secondary/40 flex flex-col items-center justify-center gap-3">
            <span className="text-6xl">👨‍👨‍👦</span>
            <p className="text-sm text-muted-foreground font-medium">The Founding Team</p>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

export default AboutUs;
