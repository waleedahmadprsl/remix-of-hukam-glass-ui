import { motion } from "framer-motion";
import { ShoppingBag } from "lucide-react";

import imgCharger from "@/assets/products/fast-charger-65w.jpg";
import imgEarbuds from "@/assets/products/earbuds-pro.jpg";
import imgPowerBank from "@/assets/products/power-bank.jpg";
import imgHub from "@/assets/products/usb-hub.jpg";

const products = [
  { name: "65W GaN Fast Charger", price: "₨ 2,499", image: imgCharger },
  { name: "TWS Earbuds Pro", price: "₨ 3,999", image: imgEarbuds },
  { name: "MagSafe Power Bank", price: "₨ 4,299", image: imgPowerBank },
  { name: "USB-C Hub 7-in-1", price: "₨ 3,199", image: imgHub },
];

const ProductCard = ({ product, i }: { product: typeof products[0]; i: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ delay: i * 0.1 }}
    className="glass-card group overflow-hidden"
  >
    <div className="relative h-48 overflow-hidden bg-secondary/30">
      <img
        src={product.image}
        alt={product.name}
        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
      />
    </div>
    <div className="p-5 relative">
      <h3 className="font-semibold text-foreground">{product.name}</h3>
      <p className="text-brand-blue font-bold mt-1">{product.price}</p>
      <motion.a
        href={`https://wa.me/923426807645?text=Hi%20HUKAM!%20I%20want%20to%20order%20${encodeURIComponent(product.name)}`}
        target="_blank"
        rel="noopener noreferrer"
        className="absolute bottom-0 left-0 right-0 bg-primary text-primary-foreground flex items-center justify-center gap-2 py-3 font-medium text-sm translate-y-full group-hover:translate-y-0 transition-transform duration-300"
      >
        <ShoppingBag className="w-4 h-4" />
        Buy on WhatsApp
      </motion.a>
    </div>
  </motion.div>
);

const ProductShowcase = () => (
  <section className="py-20">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-3xl sm:text-4xl font-bold text-center text-foreground mb-12"
      >
        Trending in Mirpur
      </motion.h2>

      <div className="flex md:hidden gap-4 overflow-x-auto pb-4 snap-x snap-mandatory -mx-4 px-4">
        {products.map((product, i) => (
          <div key={product.name} className="min-w-[75vw] snap-center">
            <ProductCard product={product} i={i} />
          </div>
        ))}
      </div>
      <div className="hidden md:grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
        {products.map((product, i) => (
          <ProductCard key={product.name} product={product} i={i} />
        ))}
      </div>
    </div>
  </section>
);

export default ProductShowcase;
