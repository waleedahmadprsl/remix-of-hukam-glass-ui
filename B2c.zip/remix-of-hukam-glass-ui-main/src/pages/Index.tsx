import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import TrustBadges from "@/components/TrustBadges";
import HowItWorks from "@/components/HowItWorks";
import ProductShowcase from "@/components/ProductShowcase";
import AllProducts from "@/components/AllProducts";
import AboutUs from "@/components/AboutUs";
import Testimonials from "@/components/Testimonials";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";

const Index = () => (
  <div className="min-h-screen bg-background">
    <Header />
    <HeroSection />
    <TrustBadges />
    <HowItWorks />
    <ProductShowcase />
    <AllProducts />
    <AboutUs />
    <Testimonials />
    <Footer />
    <WhatsAppFloat />
  </div>
);

export default Index;
